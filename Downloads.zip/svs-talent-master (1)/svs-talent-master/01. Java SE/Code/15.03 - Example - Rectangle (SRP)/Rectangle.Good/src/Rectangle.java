public interface Rectangle extends GeometricRectangle {

    void draw();
}
