public interface GeometricRectangle {

    int getArea();
}
