public interface Rectangle {

    int getArea();

    void draw();
}
