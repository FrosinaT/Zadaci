
public class DatabaseConnection {

    private Integer id;

    public DatabaseConnection(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
