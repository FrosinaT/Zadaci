package com.changeme;

public class NoPowerException extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
