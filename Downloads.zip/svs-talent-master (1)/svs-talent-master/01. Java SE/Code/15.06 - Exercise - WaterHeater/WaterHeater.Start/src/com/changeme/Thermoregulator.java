package com.changeme;

public interface Thermoregulator extends PoweredDevice {

    void setTemperature(Integer temperature);
}
