package com.changeme;

public interface PoweredDevice {

	void enablePower();
	
	void disablePower();
}
