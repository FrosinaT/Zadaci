package motiondetector;

public class MotionDetector {
    public static void main(String[] args) {

    }
}
