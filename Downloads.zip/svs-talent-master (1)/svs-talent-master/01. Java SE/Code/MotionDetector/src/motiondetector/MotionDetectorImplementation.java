package motiondetector;

public class MotionDetectorImplementation {
    public void run();

}
