package alarm;

public class Alarm {
}
