package imagecapturing;

public class ImageCapturingDeviceThread
{

}
