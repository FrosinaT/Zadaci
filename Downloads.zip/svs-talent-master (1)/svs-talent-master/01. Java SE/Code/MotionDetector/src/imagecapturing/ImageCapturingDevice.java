package imagecapturing;

import java.util.*;

public class ImageCapturingDevice {
    private ArrayList<Byte> images;
    private Scanner scanner;

    public ImageCapturingDevice() {
        images = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    public ImageCapturingDeviceThread {

    }



}
