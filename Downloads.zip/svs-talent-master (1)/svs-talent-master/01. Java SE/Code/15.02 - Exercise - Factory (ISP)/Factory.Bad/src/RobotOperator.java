public interface RobotOperator {

    void run(RobotWorker robot);
}
