public interface Door {

    void lock();

    void unlock();

    void timeOut();
}
