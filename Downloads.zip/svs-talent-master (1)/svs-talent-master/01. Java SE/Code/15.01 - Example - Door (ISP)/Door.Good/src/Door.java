public interface Door {

    void lock();

    void unlock();
}
