public interface TimerClient {

    void timeOut();
}
