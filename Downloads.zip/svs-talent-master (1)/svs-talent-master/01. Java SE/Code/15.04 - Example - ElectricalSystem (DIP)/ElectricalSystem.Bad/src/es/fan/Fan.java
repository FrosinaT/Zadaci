package es.fan;

public class Fan {

    public void enable() {
        System.out.println("es.fan.Fan.enable");
    }

    public void disable() {
        System.out.println("es.fan.Fan.disable");
    }
}
