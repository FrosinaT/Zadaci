package es.powerbutton;

public interface PoweredDevice {

    void enable();

    void disable();
}
