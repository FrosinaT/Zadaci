
public interface Human {

	 void eat();
}
