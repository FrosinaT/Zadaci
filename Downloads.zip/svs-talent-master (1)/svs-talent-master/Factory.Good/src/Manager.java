public interface Manager {

    void manage(HumanWorker human);
}
