public interface Worker {

    void work();

    void stopWorking();

}
