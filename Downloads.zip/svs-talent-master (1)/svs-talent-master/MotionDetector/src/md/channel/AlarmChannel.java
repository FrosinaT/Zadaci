package md.channel;

public interface AlarmChannel {

	public void sendAlarm();
}
