package md.device;

public interface ImageCapturingDevice {

	public byte[] getImage();
}
