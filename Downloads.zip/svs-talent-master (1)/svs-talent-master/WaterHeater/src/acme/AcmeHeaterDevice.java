package acme;

public interface AcmeHeaterDevice {
	public void enable();

	public void disable();

}
