package acme;

public interface AcmeThermometerDevice {

	public int getTemperature();
}
