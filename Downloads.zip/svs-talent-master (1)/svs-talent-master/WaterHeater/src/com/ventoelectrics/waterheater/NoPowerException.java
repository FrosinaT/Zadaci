package com.ventoelectrics.waterheater;

public class NoPowerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
