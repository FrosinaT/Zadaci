package com.ventoelectrics.power_switch;

public interface VentoPoweredDevice {

	public void enablePower();
	
	public void disablePower();
}
