
public class Box {

	int height;
	int weight;
	int depth;
}
